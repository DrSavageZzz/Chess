﻿
namespace Checkmate
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            this.label_homePage = new System.Windows.Forms.Label();
            this.btn_chessGame = new System.Windows.Forms.Button();
            this.btn_settings = new System.Windows.Forms.Button();
            this.btn_tutorial = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_homePage
            // 
            this.label_homePage.AutoSize = true;
            this.label_homePage.BackColor = System.Drawing.Color.Transparent;
            this.label_homePage.Cursor = System.Windows.Forms.Cursors.Default;
            this.label_homePage.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_homePage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label_homePage.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_homePage.Location = new System.Drawing.Point(148, 165);
            this.label_homePage.Name = "label_homePage";
            this.label_homePage.Size = new System.Drawing.Size(503, 55);
            this.label_homePage.TabIndex = 1;
            this.label_homePage.Text = "Codename: Checkmate";
            this.label_homePage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_homePage.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_chessGame
            // 
            this.btn_chessGame.BackColor = System.Drawing.Color.Transparent;
            this.btn_chessGame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_chessGame.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_chessGame.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_chessGame.Location = new System.Drawing.Point(314, 258);
            this.btn_chessGame.Name = "btn_chessGame";
            this.btn_chessGame.Size = new System.Drawing.Size(170, 45);
            this.btn_chessGame.TabIndex = 2;
            this.btn_chessGame.Text = "Chess Game";
            this.btn_chessGame.UseVisualStyleBackColor = false;
            this.btn_chessGame.Click += new System.EventHandler(this.btn_chessGame_Click);
            // 
            // btn_settings
            // 
            this.btn_settings.BackColor = System.Drawing.Color.Transparent;
            this.btn_settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_settings.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_settings.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_settings.Location = new System.Drawing.Point(314, 384);
            this.btn_settings.Name = "btn_settings";
            this.btn_settings.Size = new System.Drawing.Size(170, 45);
            this.btn_settings.TabIndex = 3;
            this.btn_settings.Text = "Settings";
            this.btn_settings.UseVisualStyleBackColor = false;
            this.btn_settings.Click += new System.EventHandler(this.btn_settings_Click);
            // 
            // btn_tutorial
            // 
            this.btn_tutorial.BackColor = System.Drawing.Color.Transparent;
            this.btn_tutorial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_tutorial.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tutorial.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_tutorial.Location = new System.Drawing.Point(314, 321);
            this.btn_tutorial.Name = "btn_tutorial";
            this.btn_tutorial.Size = new System.Drawing.Size(170, 45);
            this.btn_tutorial.TabIndex = 4;
            this.btn_tutorial.Text = "Tutorial";
            this.btn_tutorial.UseVisualStyleBackColor = false;
            this.btn_tutorial.Click += new System.EventHandler(this.btn_tutorial_Click);
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImage = global::Checkmate.Properties.Resources.Star_Wars_Homepage;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.btn_tutorial);
            this.Controls.Add(this.btn_settings);
            this.Controls.Add(this.btn_chessGame);
            this.Controls.Add(this.label_homePage);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HomePage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HomePage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.HomePage_FormClosed);
            this.Load += new System.EventHandler(this.HomePage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_homePage;
        private System.Windows.Forms.Button btn_chessGame;
        private System.Windows.Forms.Button btn_settings;
        private System.Windows.Forms.Button btn_tutorial;
    }
}