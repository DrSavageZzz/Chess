﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Checkmate
{
    public partial class SettingsPage : Form
    {

        public static bool Highlight;

        public SettingsPage()
        {
            InitializeComponent();

            box_legalMoves.Checked = Highlight;
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            // creates new homepage instance
            HomePage home = new HomePage();

            // hides settings page
            this.Hide();

            // shows homepage
            home.ShowDialog();

            // closes settings page
            this.Close();
        }

        private void SettingsPage_FormClosed(object sender, FormClosedEventArgs e)
        {
            // exits application on close
            Application.Exit();
        }

        private void box_legalMoves_CheckedChanged(object sender, EventArgs e)
        {
            Highlight = box_legalMoves.Checked;
        }

        private void SettingsPage_Load(object sender, EventArgs e)
        {

        }
    }
}
