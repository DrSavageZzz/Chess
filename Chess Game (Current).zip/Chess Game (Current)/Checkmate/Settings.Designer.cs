﻿
namespace Checkmate
{
    partial class SettingsPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsPage));
            this.btn_back = new System.Windows.Forms.Button();
            this.box_legalMoves = new System.Windows.Forms.CheckBox();
            this.label_settings = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.Transparent;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_back.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_back.Location = new System.Drawing.Point(613, 393);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(175, 45);
            this.btn_back.TabIndex = 1;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // box_legalMoves
            // 
            this.box_legalMoves.AutoSize = true;
            this.box_legalMoves.BackColor = System.Drawing.Color.Transparent;
            this.box_legalMoves.Checked = true;
            this.box_legalMoves.CheckState = System.Windows.Forms.CheckState.Checked;
            this.box_legalMoves.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box_legalMoves.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.box_legalMoves.Location = new System.Drawing.Point(335, 136);
            this.box_legalMoves.Name = "box_legalMoves";
            this.box_legalMoves.Size = new System.Drawing.Size(117, 23);
            this.box_legalMoves.TabIndex = 2;
            this.box_legalMoves.Text = "Legal Moves";
            this.box_legalMoves.UseVisualStyleBackColor = false;
            this.box_legalMoves.CheckedChanged += new System.EventHandler(this.box_legalMoves_CheckedChanged);
            // 
            // label_settings
            // 
            this.label_settings.AutoSize = true;
            this.label_settings.BackColor = System.Drawing.Color.Transparent;
            this.label_settings.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_settings.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label_settings.Location = new System.Drawing.Point(297, 78);
            this.label_settings.Name = "label_settings";
            this.label_settings.Size = new System.Drawing.Size(186, 55);
            this.label_settings.TabIndex = 3;
            this.label_settings.Text = "Settings";
            // 
            // SettingsPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Checkmate.Properties.Resources.Star_Wars_Settings;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_settings);
            this.Controls.Add(this.box_legalMoves);
            this.Controls.Add(this.btn_back);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SettingsPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.SettingsPage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.CheckBox box_legalMoves;
        private System.Windows.Forms.Label label_settings;
    }
}