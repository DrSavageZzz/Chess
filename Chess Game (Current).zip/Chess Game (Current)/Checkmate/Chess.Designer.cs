﻿using System.ComponentModel;

namespace Checkmate
{
    partial class Chess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Chess));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_location = new System.Windows.Forms.Label();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_resign = new System.Windows.Forms.Button();
            this.label_winner = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel1.Location = new System.Drawing.Point(59, 107);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 400);
            this.panel1.TabIndex = 0;
            // 
            // label_location
            // 
            this.label_location.BackColor = System.Drawing.Color.Transparent;
            this.label_location.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_location.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_location.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label_location.Location = new System.Drawing.Point(474, 107);
            this.label_location.Name = "label_location";
            this.label_location.Size = new System.Drawing.Size(159, 62);
            this.label_location.TabIndex = 1;
            this.label_location.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.Transparent;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_back.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_back.Location = new System.Drawing.Point(474, 249);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(159, 62);
            this.btn_back.TabIndex = 2;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_resign
            // 
            this.btn_resign.BackColor = System.Drawing.Color.Transparent;
            this.btn_resign.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_resign.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_resign.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_resign.Location = new System.Drawing.Point(474, 172);
            this.btn_resign.Name = "btn_resign";
            this.btn_resign.Size = new System.Drawing.Size(159, 62);
            this.btn_resign.TabIndex = 3;
            this.btn_resign.Text = "Resign";
            this.btn_resign.UseVisualStyleBackColor = false;
            this.btn_resign.Click += new System.EventHandler(this.btn_resign_Click);
            // 
            // label_winner
            // 
            this.label_winner.BackColor = System.Drawing.Color.Transparent;
            this.label_winner.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_winner.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label_winner.Location = new System.Drawing.Point(55, 63);
            this.label_winner.Name = "label_winner";
            this.label_winner.Size = new System.Drawing.Size(404, 28);
            this.label_winner.TabIndex = 4;
            this.label_winner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Chess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Checkmate.Properties.Resources.Star_Wars_Chess_Game;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.label_winner);
            this.Controls.Add(this.btn_resign);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.label_location);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Chess";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chess";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Chess_FormClosed);
            this.Load += new System.EventHandler(this.Chess_Load);
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Label label_location;

        private System.Windows.Forms.Panel panel1;

        #endregion

        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_resign;
        private System.Windows.Forms.Label label_winner;
        private System.Windows.Forms.Timer timer1;
    }
}