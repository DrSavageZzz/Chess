﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Checkmate
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private void btn_chessGame_Click(object sender, EventArgs e)
        {
            // creates new chess instance
            Chess chess = new Chess();

            // hides homepage
            this.Hide();

            // shows chess game
            chess.ShowDialog();

            // closes homepage
            this.Close();
        }

        private void btn_settings_Click(object sender, EventArgs e)
        {
            // creates new settings page instance
            SettingsPage settings = new SettingsPage();

            // hides homepage
            this.Hide();

            // shows chess game
            settings.ShowDialog();

            // closes homepage
            this.Close();
        }

        private void btn_tutorial_Click(object sender, EventArgs e)
        {
            // creates new settings page instance
            Tutorial tutorial = new Tutorial();

            // hides homepage
            this.Hide();

            // shows chess game
            tutorial.ShowDialog();

            // closes homepage
            this.Close();
        }

        private void HomePage_FormClosed(object sender, FormClosedEventArgs e)
        {
            // exits application on close
            Application.Exit();
        }

        private void HomePage_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
