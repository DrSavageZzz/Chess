﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Checkmate.ChessPieces;
using System.Threading;
using System.Collections.Generic;
using WMPLib;

namespace Checkmate
{
    public partial class Chess : Form
    {
        private ChessBoard board = new ChessBoard();

        private SettingsPage settingsPage = new SettingsPage();

        private Panel[,] chessBoard = new Panel[8, 8];

        private ChessPiece currentPiece;

        private List<Point> endPoints = new List<Point>();

        private bool whiteTurn;

        private Panel temp;

        private Cell clickedCell;

        System.Media.SoundPlayer backgroundMusic = new System.Media.SoundPlayer();

        WindowsMediaPlayer blasterNoise = new WindowsMediaPlayer();

        public Chess()
        {
            InitializeComponent();

            CreateVisualBoard();

            whiteTurn = true;

            label_winner.Text = "Whites Turn";

            // sets volume of piece movement noise
            blasterNoise.settings.volume = 10;

            // creates and plays background music
            backgroundMusic.SoundLocation = "StarWars.wav";

            backgroundMusic.PlayLooping();
        }

        private void CreateVisualBoard()
        {
            int panelSize = panel1.Width / 8;
            panel1.Height = panel1.Width;



            for (int i = 0; i < board.Size; i++)
            {
                for (int j = 0; j < board.Size; j++)
                {
                    // create panel for each row, column
                    chessBoard[i, j] = new Panel();


                    // set the size for each panel
                    chessBoard[i, j].Size = new Size(panelSize, panelSize);
                    chessBoard[i, j].BackgroundImageLayout = ImageLayout.Stretch;
                    chessBoard[i, j].BorderStyle = BorderStyle.FixedSingle;


                    // setting a location for each panel
                    chessBoard[i, j].Location = new Point(j * panelSize, i * panelSize);
                    chessBoard[i, j].Click += pieceClick;
                    chessBoard[i, j].Tag = new Point(i, j);


                    // adding each panel to a main panel
                    panel1.Controls.Add(chessBoard[i, j]);


                    // Colors each square 
                    SettingUpEachSquare(i, j, Color.White, Color.LightGreen);
                }
            }

            SetUpPieces();
        }


        /// <summary>
        /// Initializing all chess pieces on the board (visually)
        /// </summary>
        private void SetUpPieces()
        {
            for (int i = 0; i < board.Size; i++)
            {
                // Setting up black and white piece pawn images on the board
                chessBoard[1, i].BackgroundImage = new Pawn(ChessPiece.PieceColor.BLACK).PieceImage;

                chessBoard[6, i].BackgroundImage = new Pawn(ChessPiece.PieceColor.WHITE).PieceImage;

                endPoints.Add(new Point(0, i));

                endPoints.Add(new Point(7, i));
            }

            BlackPieces(0);

            WhitePieces(7);
        }


        /// <summary>
        /// Setting the black chess pieces on the board
        /// </summary>
        void BlackPieces(int row)
        {

            chessBoard[row, 0].BackgroundImage = new Rook(ChessPiece.PieceColor.BLACK).PieceImage;

            chessBoard[row, 1].BackgroundImage = new Knight(ChessPiece.PieceColor.BLACK).PieceImage;

            chessBoard[row, 2].BackgroundImage = new Bishop(ChessPiece.PieceColor.BLACK).PieceImage;

            chessBoard[row, 3].BackgroundImage = new Queen(ChessPiece.PieceColor.BLACK).PieceImage;

            chessBoard[row, 4].BackgroundImage = new King(ChessPiece.PieceColor.BLACK).PieceImage;

            chessBoard[row, 5].BackgroundImage = new Bishop(ChessPiece.PieceColor.BLACK).PieceImage;

            chessBoard[row, 6].BackgroundImage = new Knight(ChessPiece.PieceColor.BLACK).PieceImage;

            chessBoard[row, 7].BackgroundImage = new Rook(ChessPiece.PieceColor.BLACK).PieceImage;
        }


        /// <summary>
        /// Setting the white chess pieces on the board
        /// </summary>
        void WhitePieces(int row)
        {

            chessBoard[row, 0].BackgroundImage = new Rook(ChessPiece.PieceColor.WHITE).PieceImage;

            chessBoard[row, 1].BackgroundImage = new Knight(ChessPiece.PieceColor.WHITE).PieceImage;

            chessBoard[row, 2].BackgroundImage = new Bishop(ChessPiece.PieceColor.WHITE).PieceImage;

            chessBoard[row, 3].BackgroundImage = new Queen(ChessPiece.PieceColor.WHITE).PieceImage;

            chessBoard[row, 4].BackgroundImage = new King(ChessPiece.PieceColor.WHITE).PieceImage;

            chessBoard[row, 5].BackgroundImage = new Bishop(ChessPiece.PieceColor.WHITE).PieceImage;

            chessBoard[row, 6].BackgroundImage = new Knight(ChessPiece.PieceColor.WHITE).PieceImage;

            chessBoard[row, 7].BackgroundImage = new Rook(ChessPiece.PieceColor.WHITE).PieceImage;
        }

        /// <summary>
        /// When a cell is even or odd then set the color to white, otherwise set it to green
        /// </summary>
        private void SettingUpEachSquare(int i, int j, Color c1, Color c2)
        {
            chessBoard[i, j].BackColor = EvenOrOdd(i, j) ? c1 : c2;
        }


        /// <summary>
        /// Returns true if a cell coordinate is even or odd
        /// e.g (0,0) or (1,1)
        /// </summary>
        private bool EvenOrOdd(int i, int j)
        {
            return (i % 2 == 0 && j % 2 == 0 || i % 2 != 0 && j % 2 != 0);
        }

     
        
        private void HighlightLegalMove(ChessPiece piece)
        {
            for (int i = 0; i < board.Size; i++)
            {
                for (int j = 0; j < board.Size; j++)
                {

                    if (board.board[i, j].IsLegal && board.board[i, j].IsOccupied != true)
                    {
                        
                        chessBoard[i, j].BackColor = Color.Red;
                    }
                    
                    else if(board.board[i, j].IsLegal && board.board[i, j].IsOccupied == true)
                    {

                        if( board.board[i,j].GetChessPiece().GetPieceColor() != piece.GetPieceColor())
                        {
                            chessBoard[i, j].BackColor = Color.Red;
                        }
                    } 
                }
            }
            
        }

        private void ResettingBoardColors()
        {

            for (int i = 0; i < board.Size; i++)
            {
                for (int j = 0; j < board.Size; j++)
                {

                    if (chessBoard[i,j].BackColor == Color.Red)
                    {
                        SettingUpEachSquare(i,j,Color.White, Color.LightGreen);
                        
                    }
                    
                   
                }
            }

        }
        public bool PlayerHasMoved(Panel clickedPiece)
        {

            return clickedPiece.BackColor == Color.Red;

        }

        public void Castle(Point location)
        {
            if (board.board[location.X, location.Y].GetChessPiece().GetPieceColor() == ChessPiece.PieceColor.BLACK)
            {
               
            }
        }

        private void PawnIntoQueen(Point location)
        {
            foreach (var endPoint in endPoints)
            {
                if (location == endPoint)
                {
                    SettingPawnToQueen(location,
                        location.X == 0 ? ChessPiece.PieceColor.WHITE : ChessPiece.PieceColor.BLACK);
                }
            }
        }

        private void SettingPawnToQueen(Point location, ChessPiece.PieceColor pieceColor)
        {
            chessBoard[location.X, location.Y].BackgroundImage = new Queen(pieceColor).PieceImage;
            board.board[location.X, location.Y] = new Cell(location.X, location.Y, new Queen(pieceColor));
        }

        private void SwapTurn(Cell currentCell, ChessPiece piece, Point location)
        {
            ShowMoves(currentCell, piece, whiteTurn ? ChessPiece.PieceColor.WHITE : ChessPiece.PieceColor.BLACK, location);
        }

        private void ShowMoves(Cell currentCell, ChessPiece piece, ChessPiece.PieceColor pieceColor, Point location)
        {
            if (currentCell.IsOccupied)
            {
                if (piece.GetPieceColor() == pieceColor)
                {
                    board.ClearBoard();

                    piece.ShowLegalMoves(board, location);

                    if (SettingsPage.Highlight)
                    {
                        HighlightLegalMove(piece);
                    }
                }
                else
                {
                    board.ClearBoard();
                }
            }
        }

        private void pieceClick(object sender, EventArgs e)
        {
            Panel clickedPiece = (Panel) sender;
            
            Point location = (Point) clickedPiece.Tag;
            
            Cell currentCell = board.board[location.X, location.Y];

            
            ChessPiece piece = currentCell.GetChessPiece();

            label_location.Text = "You clicked a square at location " + currentCell.RowNum + ", " + currentCell.ColNum;

            SwapTurn(currentCell, piece, location);
          
            #region Start of being able to move piece
            bool movePiece = currentPiece == null;
            // selects a chess piece
            if (movePiece || !board.board[location.X, location.Y].IsLegal)
            {
                
                temp = clickedPiece;
                currentPiece = piece;
                clickedCell = currentCell;
                
            }
            else
            {
                // move piece only in RED squares
                if (board.board[location.X, location.Y].IsLegal)
                {
                    // creates and plays piece movement noise
                    blasterNoise.URL = "blaster.wav";

                    blasterNoise.controls.play();

                    clickedPiece.BackgroundImage = currentPiece.PieceImage;

                    temp.BackgroundImage = null;

                    ResettingBoardColors();

                    board.SetCell(location.X, location.Y, new Cell(location.X, location.Y, currentPiece));

                    // Pawn can move up one square after initial turn
                    if (currentPiece is Pawn)
                    {
                        currentPiece.SetPieceMoved(true);

                        PawnIntoQueen(location);
                    }
                    if(currentPiece is King)
                    {
                        currentPiece.SetPieceMoved(true);
                        Castle(location);
                    }
                    if(currentPiece is Rook)
                    {
                        currentPiece.SetPieceMoved(true);
                    }


                    board.SetCell(clickedCell.RowNum, clickedCell.ColNum, new Cell(clickedCell.RowNum, clickedCell.ColNum, null));

                    // swapping turns
                    whiteTurn = !whiteTurn;

                    if (whiteTurn)
                    {
                        label_winner.Text = "Whites Turn";
                    }
                    else
                    {
                        label_winner.Text = "Blacks Turn";
                    }
                }

                currentPiece = null;
            }

            #endregion END OF MOVING PIECE
            
        }

        private void DoTimeConsumingWork()
        {
            Thread.Sleep(5000);
        }
        
        private void btn_resign_Click(object sender, EventArgs e)
        {
            // puts text into label depending on winner
            if (!whiteTurn)
            {
                label_winner.Text = "The Winner Is White!";
            }
            else
            {
                label_winner.Text = "The Winner Is Black!";
            }

            // makes rest of code wait for workerThread
            Thread workerThread = new Thread(DoTimeConsumingWork);

            // workerThread starting
            workerThread.Start();

            // workerThread completing execution (forcing main thread to wait)
            workerThread.Join();

            // stops background music
            backgroundMusic.Stop();

            // creates new homepage instance
            HomePage home = new HomePage();

            // hides chess game
            this.Hide();

            // shows homepage
            home.ShowDialog();

            // closes chess game
            this.Close();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            // stops background music
            backgroundMusic.Stop();

            // creates new homepage instance
            HomePage home = new HomePage();

            // hides chess game
            this.Hide();

            // shows homepage
            home.ShowDialog();

            // closes chess game
            this.Close();
        }

        private void Chess_FormClosed(object sender, FormClosedEventArgs e)
        {
            // exits application on close
            Application.Exit();
        }

        private void Chess_Load(object sender, EventArgs e)
        {

        }
    }
}